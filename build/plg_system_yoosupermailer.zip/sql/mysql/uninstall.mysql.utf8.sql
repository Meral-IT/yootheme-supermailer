/*
 * Filename: f:\Projekte\yootheme-supermailer\sql\mysql\install.mysql.utf8.sql
 * Path: f:\Projekte\yootheme-supermailer\sql\mysql
 * Created Date: Tuesday, July 30th 2024, 9:19:10 pm
 * Author: Necati Meral https://meral.cloud
 * 
 * Copyright (c) 2024 Meral IT
 */

DROP TABLE IF EXISTS `#__supermailer`
